Hi!

This is Javae Elliott's work for the project.

All the folder names should be following the guide from the Brightspace submission, but I took them from a 'main' file altogether ( except profiling, that part is not on the 'main' file). The main file is salescode.sc, everything has proof that it has run smoothly.

First you need to have uploaded the sales.csv file to HDFS.
I downloaded the file from NYCOpenData, then used the 'Upload File' tool on Dataproc.

Then used the command once uploaded to dataproc
hdfs -dfs -put sales.csv

Now you need to be in Spark Scala,so:
spark-shell --deploy-mode client

After that, you can completely select all of the file and paste onto the prompt line, it should run all of the code and acknowledge comments as commented and not do anything about them. I have proof of that working for me in /screenshots!

Thank you!


