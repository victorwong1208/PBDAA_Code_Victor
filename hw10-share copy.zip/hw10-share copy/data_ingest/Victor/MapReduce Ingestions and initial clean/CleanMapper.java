import java.io.IOException;
import java.io.StringReader;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CleanMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
    public void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        try {
            String line = value.toString();
            String[] arr = line.split(",");
    
            if (arr == null) {
                return; // skip empty lines
            }
            if (arr.length < 15) {
                return;
            }
            if (arr[0] == null || arr[4] == null || arr[5] == null || arr[6] == null || arr[9] == null) {
                return;// skip missing values
            }
            
            String boroughCode;
            if (arr[0].charAt(0) == '1') {
                boroughCode = "manhattan";
            } else if (arr[0].charAt(0) == '2') {
                boroughCode = "bronx";
            } else if (arr[0].charAt(0) == '3') {
                boroughCode = "brooklyn";
            } else if (arr[0].charAt(0) == '4') {
                boroughCode = "queens";
            } else if (arr[0].charAt(0) == '5') {
                boroughCode = "queens";
            } else {
                boroughCode = "other";
            }
            
            String s = arr[0] + "," + arr[4] + "," + arr[5] + "," + arr[6] + "," + arr[9]+ ","+ boroughCode;
            context.write(new Text(s), new IntWritable(1));
        } catch (IOException e) {
            System.out.println("found exception!");
        }
    }
}
