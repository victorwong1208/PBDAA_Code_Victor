val df = spark.read.option("header",true).csv("joinedoutput.csv")
/*df: org.apache.spark.sql.DataFrame = [borough: string, neighborhood: string ... 17 more fields]*/

// Presumption: the condo data is cleaned based on tax status - only residential unitsand only cash considerating purchases to avoid inheritance and corporate acquisitions

df.printSchema()
/*
root
 |-- borough: string (nullable = true)
 |-- neighborhood: string (nullable = true)
 |-- building_class: string (nullable = true)
 |-- address: string (nullable = true)
 |-- apt_number: string (nullable = true)
 |-- zipcode: string (nullable = true)
 |-- res_units: string (nullable = true)
 |-- com_units: string (nullable = true)
 |-- total_units: string (nullable = true)
 |-- land_sq_ft: string (nullable = true)
 |-- year_built: string (nullable = true)
 |-- tax_class_toi: string (nullable = true)
 |-- building_class_toi: string (nullable = true)
 |-- sale_price: string (nullable = true)
 |-- date: string (nullable = true)
 |-- BIN: string (nullable = true)
 |-- num_complaints: string (nullable = true)
 |-- num_illegal: string (nullable = true)
 |-- num_legal: string (nullable = true)
 */

 spark.sql("SELECT COUNT(*) FROM df").show()
 /*res2: Long = 246312*/
 // Analysis: This is a fairly large dataset to work with. This size of data can be fairly representative of the sales price of condo in this data.


 //distribution of the borough, how many units/unique bins in each borough
 val unitsDF = df.select($"borough", $"total_units", $"BIN").groupBy("borough").agg(count("*").alias("total_units"), countDistinct("BIN").alias("unique_bins"))

 unitsDF.show()
 /*+-------------+-----------+-----------+                                         
|      borough|total_units|unique_bins|
+-------------+-----------+-----------+
|       QUEENS|      68916|      34474|
|     BROOKLYN|      63793|      29451|
|        BRONX|      21005|      10416|
|    MANHATTAN|      77885|       8722|
|STATEN ISLAND|      14713|      11085|
+-------------+-----------+-----------+*/
//Analysis: Our data looks fair. The distribution of the units and bins(representing each unique condo building). Each borough has fairly much units(representing each transaction)
//and bins to be analyzed. With this, we are able to achieve the data integrity and liability

//non null sqft in borough
val nonNullLandSqftDF = df.filter(col("land_sq_ft").isNotNull)
val nonNullLandSqftByBoroughDF = nonNullLandSqftDF.groupBy("borough").agg(count("land_sq_ft").alias("count_non_null_land_sqft")).orderBy(desc("count_non_null_land_sqft"))

nonNullLandSqftByBoroughDF.show()
/*+-------------+------------------------+
|      borough|count_non_null_land_sqft|
+-------------+------------------------+
|    MANHATTAN|                   19756|
|     BROOKLYN|                   14118|
|       QUEENS|                   14045|
|        BRONX|                    3781|
|STATEN ISLAND|                    2470|
+-------------+------------------------+*/
// Analysis: we cannot make sure that every entry has sqft info but these are enough for providing strong and solid sample



// Calculate average land_sq_ft per borough
val df_avg_sqft = df.groupBy("borough").agg(avg("land_sq_ft").alias("avg_sqft"))


val df_avg_price_sqft = df.filter($"sale_price".isNotNull && $"land_sq_ft".isNotNull).withColumn("price_sqft", $"sale_price"/$"land_sq_ft").groupBy("borough").agg(avg("price_sqft").alias("avg_price_sqft"))


val df_result = df_avg_sqft.join(df_avg_price_sqft, Seq("borough"))

df_result.show()

/*+-------------+------------------+------------------+                           
|      borough|          avg_sqft|    avg_price_sqft|
+-------------+------------------+------------------+
|       QUEENS| 1446.857742969028| 339.5422576068646|
|     BROOKLYN| 840.5550361240969|1121.2516093397394|
|        BRONX|1335.1232478180375| 383.1919803984935|
|    MANHATTAN| 235.9675541607613|3209.8701911984926|
|STATEN ISLAND|3064.1052631578946|205.65737596951408|
+-------------+------------------+------------------+*/

// Analysis: here, we can see that staten island has the both the higest avg sqft and avg price per sqft
// manhatthan has the lowest avg sqft and higest avg price per sqft
// generally, the distribution we see is highly inbalanced. and we can see there might be a negative correlation between the
// avg_sqft and avg price sqft

// whats the correlation in df ressult?
val corrValue = df_result.stat.corr("avg_sqft", "avg_price_sqft")
/*corrValue: Double = -0.7445463305805088*/
// Analysis: This is a fairly strong negative correlation between the avg sqft of the borough and the avg_price_square feet.

// avg price of each area
val df_avg_price = df.groupBy("borough").agg(avg("sale_price").alias("average_price"))
val total_avg_price = df.agg(avg("sale_price")).first().getDouble(0)
/*total_avg_price: Double = 1493225.2086662445*/
val df_avg_price_percent_change = df_avg_price.withColumn("difference to city avg(%)", (col("average_price") - total_avg_price) / total_avg_price * 100).orderBy(col("difference to city avg(%)").desc)

df_avg_price_percent_change.show()
/*+-------------+------------------+-------------------------+
|      borough|     average_price|difference to city avg(%)|
+-------------+------------------+-------------------------+
|    MANHATTAN|2570958.7808178724|        72.17488466553979|
|     BROOKLYN|1322996.1678554073|      -11.400091548339619|
|        BRONX|1041897.6736967389|      -30.225014441902797|
|       QUEENS| 770796.9147222706|       -48.38039766213498|
|STATEN ISLAND| 554405.4649629579|       -62.87194578919845|
+-------------+------------------+-------------------------+*/

//Analysis: Here, we can see that sales price in boroughs varies and shows a large gap in between manhattan and others
// We can see that not very different from the distribution of avg_price_sqft, the general avg price distribution shows 
// the enormous advantage of price in manhattan. 



// With this in mind, let's look at the how are the complaints distributions among these boroughs

// find out the geographical distribution of top 20% most complained house(may have may units)
val df_top_bin = df.withColumn("num_complaints_numeric", col("num_complaints").cast("int")).groupBy("borough", "bin").agg(max("num_complaints_numeric").alias("total_complaints")).orderBy(col("total_complaints").desc)
/*df_top_bin: org.apache.spark.sql.Dataset[org.apache.spark.sql.Row] = [borough: string, bin: string ... 1 more field]*/

val top25percent = (df_top_bin.count() * 0.25).toInt
/*top25percent: Int = 23537*/

val df_top_boroughs = df_top_bin.limit(top25percent).groupBy("borough").agg(count("bin").alias("num_top_bins")).orderBy(col("num_top_bins").desc)
val total_top_bins = df_top_boroughs.agg(sum("num_top_bins")).first().getLong(0)
val df_top_boroughs_percent = df_top_boroughs.withColumn("percent", col("num_top_bins") / total_top_bins * 100)
df_top_boroughs_percent.show()
/*
+-------------+------------+------------------+
|      borough|num_top_bins|           percent|
+-------------+------------+------------------+
|     BROOKLYN|        7597|32.276840718868165|
|       QUEENS|        6804| 28.90767727407911|
|    MANHATTAN|        5490| 23.32497769469346|
|        BRONX|        2620|11.131410120236223|
|STATEN ISLAND|        1026| 4.359094192123041|
+-------------+------------+------------------+*/

//Analysis: here, we can see the most complained bins(buildings) are in brooklyn, queens, and manhattan, leaving bronx and staten island a
//fairly small amount. With this in mind, we can say that Bronx and Staten island generally has more lower cost unitss(per sqft and generally)
// and a safer choice to avoid building that are top-complained.

// find out the geographical distribution of top 20% least complained house(may have may units)
val df_least_bin = df.withColumn("num_complaints_numeric", col("num_complaints").cast("int")).groupBy("borough", "bin").agg(max("num_complaints_numeric").alias("total_complaints")).orderBy(col("total_complaints").asc)
/*df_least_bin: org.apache.spark.sql.Dataset[org.apache.spark.sql.Row] = [borough: string, bin: string ... 1 more field]*/

val least25percent = (df_top_bin.count() * 0.25).toInt
/*top25percent: Int = 23537*/

val df_least_boroughs = df_least_bin.limit(least25percent).groupBy("borough").agg(count("bin").alias("num_least_bins")).orderBy(col("num_least_bins").desc)
val total_least_bins = df_least_boroughs.agg(sum("num_least_bins")).first().getLong(0)
val df_least_boroughs_percent = df_least_boroughs.withColumn("percent", col("num_least_bins") / total_least_bins * 100)
df_least_boroughs_percent.show()
/*+-------------+--------------+------------------+
|      borough|num_least_bins|           percent|
+-------------+--------------+------------------+
|       QUEENS|          9156| 38.90045460339041|
|     BROOKLYN|          6931|29.447253260823388|
|STATEN ISLAND|          4377| 18.59625270850151|
|        BRONX|          2531|10.753282066533544|
|    MANHATTAN|           542| 2.302757360751158|
+-------------+--------------+------------------+*/
//Analysis: here, we can see most of the least complained bins(buildings) are in queens and brooklyn, leaving manhattan a
//fairly small amount. With this in mind, we can say that queens and brooklyn generally has more lower cost unitss(per sqft and generally)
// and easier areas to find buildings that don't have much complaints, while it's very rare to find some least-complained buildings in manhattan, facing effectively
// higher price and generally lower condo size.


// now let's look into some most complained zipcodes and their avg prices
val df_top_bin_zipcode_sale = df.withColumn("num_complaints_numeric", col("num_complaints").cast("int")).withColumn("sale_price_numeric", col("sale_price").cast("int")).groupBy("borough", "bin", "zipcode").agg(max("num_complaints_numeric").alias("total_complaints"), avg("sale_price_numeric").alias("avg_sale_price")).orderBy(col("total_complaints").desc)
val df_top_zipcode_borough_sale = df_top_bin_zipcode_sale.groupBy("borough", "zipcode").agg(sum("total_complaints").alias("total_complaints_by_zipcode"), avg("avg_sale_price").alias("avg_sale_price")).orderBy(col("total_complaints_by_zipcode").desc)

val df_top_zipcode_borough_sale_diff = df_top_zipcode_borough_sale.withColumn("avg_sale_price_diff(%)", (col("avg_sale_price") - total_avg_price) / total_avg_price * 100)
import org.apache.spark.sql.expressions.Window
val windowSpec = Window.partitionBy("borough").orderBy(col("total_complaints_by_zipcode").desc)

val df_top_zipcode_borough_ranked = df_top_zipcode_borough_sale_diff.withColumn("rank", dense_rank().over(windowSpec)).filter(col("rank") <= 5)

df_top_zipcode_borough_ranked.show(25)

/*

+-------------+-------+---------------------------+------------------+----------------------+----+
|      borough|zipcode|total_complaints_by_zipcode|    avg_sale_price|avg_sale_price_diff(%)|rank|
+-------------+-------+---------------------------+------------------+----------------------+----+
|       QUEENS|  11355|                       9539|1479485.3121312158|   -0.9201489805614279|   1|
|       QUEENS|  11419|                       8498| 606048.0656645569|   -59.413485511279184|   2|
|       QUEENS|  11368|                       6945| 973216.5307403925|    -34.82453114961313|   3|
|       QUEENS|  11373|                       5551| 1351644.348504984|    -9.481547682129015|   4|
|       QUEENS|  11385|                       5524|  985389.012772261|    -34.00935056190118|   5|
|     BROOKLYN|  11221|                       9280|1462170.6463720454|   -2.0796971624887854|   1|
|     BROOKLYN|  11235|                       8752|1016513.3676518596|     -31.9249794503661|   2|
|     BROOKLYN|  11215|                       8702| 2227457.302310739|     49.17088791317112|   3|
|     BROOKLYN|  11207|                       7715|1095142.3232855764|    -26.65926633640464|   4|
|     BROOKLYN|  11208|                       6865| 721668.3202311789|   -51.670497119736126|   5|
|        BRONX|  10462|                       5135| 602777.0866886063|    -59.63254014262125|   1|
|        BRONX|  10467|                       4780|1188736.8104096758|    -20.39132452957576|   2|
|        BRONX|  10463|                       4188|1293440.2785753862|    -13.37942387600777|   3|
|        BRONX|  10458|                       3787|2082650.4685846148|     39.47329957313322|   4|
|        BRONX|  10457|                       3595|1328618.5418538323|   -11.023566027219674|   5|
|    MANHATTAN|  10011|                       9413|  5317421.23541266|      256.103098484535|   1|
|    MANHATTAN|  10025|                       8758| 6076173.746134039|      306.916097509585|   2|
|    MANHATTAN|  10023|                       7589|   5424900.9334714|    263.30092085151347|   3|
|    MANHATTAN|  10013|                       7384|6534183.8833090225|     337.5886400381216|   4|
|    MANHATTAN|  10003|                       7152| 5917778.647620894|     296.3085148359289|   5|
|STATEN ISLAND|  10314|                       5093|  597819.951711487|   -59.964515182176534|   1|
|STATEN ISLAND|  10306|                       4574| 557985.0981272804|    -62.63222085396782|   2|
|STATEN ISLAND|  10312|                       3956| 629191.7052110248|    -57.86357599916079|   3|
|STATEN ISLAND|  10305|                       3337|  548759.587385711|    -63.25004532465229|   4|
|STATEN ISLAND|  10301|                       3190| 692856.1350934777|    -53.60002422458834|   5|
+-------------+-------+---------------------------+------------------+----------------------+----+
*/
// Analysis: here, we list out all the top-complained zipdodes in each borough and see their avg price. we can see
// for everywhere besides manhattan, the sales price is much below sales prive avg. What's more interesting,
// is that even in the top-complained area in manhattan, the avg price doubles/triples the city avg price.
// it's possible to say that if we are trying to find lower prices in the area even it's very heavily complained,
// it's hard to find prices in a area that is already very expensive.
// also, we should be mindful when choosing in these zipcodes

// now, let's look at the correlation between the avg sales price of the zipcode, and the total complaints of the zipcode
val df_corr = df_top_zipcode_borough_sale.groupBy("borough").agg(corr("avg_sale_price", "total_complaints_by_zipcode").alias("correlation"))
df_corr.show()
/*+-------------+--------------------+
|      borough|         correlation|
+-------------+--------------------+
|       QUEENS| 0.08290348745692676|
|     BROOKLYN|-0.36995002036805275|
|        BRONX|-0.13934648650593023|
|    MANHATTAN|-0.16684154852686203|
|STATEN ISLAND|   0.123027795356999|
+-------------+--------------------+*/
/*Analysis: Here, we can see that for each borough, there are very week correlation between avg_sale_price of the zipcode and total complaints by zipcode.
Without a solid correlation value, it's even less likely that there exists a causal relationship between the number of complaints a zipcode receives in total
and the average price of the zipcode. In Brooklyn, there is a very weak negative correlation effect between the number of complaints a zipcode receives in total
and the average price of the zipcode. But generally, it's unlikely that price and complaints are closely connected.*/

// we analyzed the relationship between avg price of the zip code and the total complaints in one zipcode from zipcode level,
// now we are going to analyze the relationship between avg_sqft and avg_price_per_sqft from the zipcode level in each borough

val df_avg_price_sqft = df.withColumn("sale_price_numeric", col("sale_price").cast("int")).withColumn("land_sq_ft_numeric", col("land_sq_ft").cast("int")).groupBy("borough", "zipcode").agg(avg("land_sq_ft_numeric").alias("avg_sqft"),(avg("sale_price_numeric") / avg("land_sq_ft_numeric")).alias("avg_price_per_sqft"))
val corrValue = df_avg_price_sqft.groupBy("borough").agg(corr("avg_sqft", "avg_price_per_sqft").alias("correlation"))
corrValue.show()
/*
+-------------+--------------------+
|      borough|         correlation|
+-------------+--------------------+
|       QUEENS| -0.7348813327160127|
|     BROOKLYN| -0.3781392098821628|
|        BRONX| -0.5106496940029526|
|    MANHATTAN|-0.15005846031573067|
|STATEN ISLAND| -0.5915828316789072|
+-------------+--------------------+*/

// Analysis: here, we can see that for borough of queens, it has a considerably strong negative correlation between avg sqft in a zipcode and the avg_price_per_sqft
// which means that for people looking for buy/sell house in queens, there is a better chance you can find a better deal when looking at larger condo unit
// brooklyn, bronx, and a staten ilsand has medium correlation, which means that there is still a better chance you can find a better deal.
// manhatthan, the correlation is really weak
// generally, the distribution we see is highly inbalanced. and we can see there is a negative correlation betwee avg sqft in a zipcode and the avg_price_per_sqft in a zipcode


/* General Analysis Summary
Here, we presented the distribution of the buildings, units in general.
We also presented the distribution of most/least complained bin, to get a general idea on which area to buy their house.
From the analysis, we saw some fairly strong correlation between the avg_sqft and avg_price_per_sqft, on borough level and on zipcode level in a certain
borough, in which Queens shows the strongest negative correlation that makes it an ideal area to go for bigger place.
At the same time, we can see that the housing price and housing size is highly inbalanced in different boroughs, leading queens, staten island, and bronx 
to be ideal borough to look for cheaper, more spacious, and more building choices for least 25% complained buildings.
From this analysis, we not only find out the weak-to-almost-none correlation between num of complaints and the avg price, possibly denying the theory that the num 
of complaints may have strong influence on the price of the building/area.*/





